import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, TextInput, FlatList,Image } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

const Stack = createNativeStackNavigator();


function HomeScreen({ navigation }) {
  const [name, setName] = useState('');

  return (
    <View style={styles.container}>
     <Image source={require('./Capture.PNG')} style={styles.image} />
      <Text style={styles.title}>MANAGE YOUR TASK</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your name"
        value={name}
        onChangeText={setName}
      />
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('SecondScreen', { name })}
      >
        <Text style={styles.buttonText}>GET STARTED</Text>
      </TouchableOpacity>
    </View>
  );
}

// SecondScreen
function SecondScreen({ route, navigation }) {
  const { name } = route.params;
  const [tasks, setTasks] = useState([
    { id: '1', title: 'To check email', completed: false },
    { id: '2', title: 'UI task web page', completed: false },
    { id: '3', title: 'Learn javascript basic', completed: false },
    { id: '4', title: 'Learn HTML Advance', completed: false },
    { id: '5', title: 'Medical App UI', completed: false },
    { id: '6', title: 'Learn Java', completed: false },
  ]);

  const renderTaskItem = ({ item }) => (
    <View style={styles.taskContainer}>
      <TouchableOpacity
        onPress={() => {
          setTasks((prevTasks) =>
            prevTasks.map((task) =>
              task.id === item.id ? { ...task, completed: !task.completed } : task
            )
          );
        }}
      >
        <Ionicons
          name={item.completed ? 'checkbox-outline' : 'square-outline'}
          size={24}
          color="green"
        />
      </TouchableOpacity>
      <Text style={styles.taskTitle}>{item.title}</Text>
      <TouchableOpacity>
        <Ionicons name="pencil-outline" size={24} color="red" />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={tasks}
        renderItem={renderTaskItem}
        keyExtractor={(item) => item.id}
        style={{ width: '100%' }}
      />
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate('ThirdScreen')}
      >
        <Ionicons name="add-circle" size={60} color="#00BFFF" />
      </TouchableOpacity>
    </View>
  );
}

// ThirdScreen
function ThirdScreen({ navigation }) {
  const [newTask, setNewTask] = useState('');

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ADD YOUR JOB</Text>
      <TextInput
        style={styles.input}
        placeholder="Input your job"
        value={newTask}
        onChangeText={setNewTask}
      />
      <TouchableOpacity
        style={styles.button}
        onPress={() => {
      
          navigation.goBack();
        }}
      >
        <Text style={styles.buttonText}>FINISH</Text>
      </TouchableOpacity>
       <Image source={require('./Capture.PNG')} style={styles.image2} />
    </View>
  );
}

// App Navigator
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="HomeScreen">
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
        <Stack.Screen name="SecondScreen" component={SecondScreen} />
        <Stack.Screen name="ThirdScreen" component={ThirdScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title:{
fontSize:30,
color:'red',
fontWeight:'bold',
textAlign: 'center',
margin:20

  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
    

  },
  button: {
    backgroundColor: '#2196F3',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  taskContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    backgroundColor: '#F0F0F0',
    marginVertical: 5,
    width: '100%',
  },
  taskTitle: {
    flex: 1,
    fontSize: 16,
    marginLeft: 10,
  },
  addButton: {
    position: 'absolute',
    bottom: 30,
    right: 30,
  },
  image2:{
    marginTop:20,
    marginLeft:50,
  }
});
